module.exports = function(dataBlock,ProxyTask){
    //return headerObj
    return {
        "SOAPAction":'"rpc/http://siebel.com/loyalty/BSShuYunGuideSystemWS:GetGuideMemMsg"'
    };

};