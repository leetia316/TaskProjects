module.exports={
    "PushGoods2ShuYun":{
        "TaskStatus":"stop",
        "Batch":100
    },
    "PushClassify2ShuYun":{
        "TaskStatus":"start",
        "Batch":100
    },
    "PushMemberGuide2ShuYun":{
        "TaskStatus":"start",
        "Batch":100
    },
    "PushMemberGuide2CRM": {
        "TaskStatus": "start",
        "Batch": 50
    }
};
